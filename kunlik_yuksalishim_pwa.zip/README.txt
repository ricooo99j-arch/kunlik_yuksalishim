KUNLIK YUKSALISHIM — PWA

Bu papkani HTTPS orqali ishlaydigan hostingga joylash kerak (masalan, GitHub Pages).
Faqat telefon xotirasidagi HTML faylni ochish PWA sifatida o'rnatish uchun yetarli emas.

Fayllar:
- index.html: ilova
- manifest.webmanifest: o'rnatish ma'lumotlari
- sw.js: offline ishlash uchun service worker
- icon-192.png va icon-512.png: ilova ikonkalari

Hostingga joylagandan so'ng Chrome'da HTTPS manzilini oching:
Chrome menyusi (⋮) -> Ilovani o'rnatish / Bosh ekranga qo'shish.

Eslatma: kunlik belgilashlar shu qurilmadagi brauzer xotirasida saqlanadi.
